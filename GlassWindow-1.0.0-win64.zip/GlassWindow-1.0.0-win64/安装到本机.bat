@echo off
setlocal
if not exist "%~dp0GlassWindow.exe" (
    echo GlassWindow.exe was not found.
    pause
    exit /b 1
)

"%~dp0GlassWindow.exe" --install
if errorlevel 1 (
    echo Installation failed.
    pause
    exit /b 1
)

echo Installed successfully.
echo You can now launch GlassWindow from the Start menu.
timeout /t 3 >nul
