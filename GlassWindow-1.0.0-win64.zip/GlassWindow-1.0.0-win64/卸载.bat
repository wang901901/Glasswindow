@echo off
setlocal
set "GW=%LOCALAPPDATA%\Programs\GlassWindow\GlassWindow.exe"
if not exist "%GW%" set "GW=%~dp0GlassWindow.exe"
if not exist "%GW%" (
    echo GlassWindow.exe was not found.
    pause
    exit /b 1
)

"%GW%" --uninstall
if errorlevel 1 (
    echo Uninstall completed with errors.
) else (
    echo Uninstall completed.
)
echo Report: %TEMP%\GlassWindow-uninstall-report.txt
pause
