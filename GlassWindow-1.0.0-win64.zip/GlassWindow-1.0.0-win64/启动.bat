@echo off
setlocal
start "" "%~dp0GlassWindow.exe"
